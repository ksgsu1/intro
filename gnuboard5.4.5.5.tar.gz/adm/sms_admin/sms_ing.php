<?php
include_once("./_common.php");

$g5['title'] = "SMS 전송 중";
?>

<!doctype html>
<html lang="ko">
<head>
<meta charset="utf-8">
<title>SMS 전송 중</title>
<style>
body {margin:0;padding:0;background:#000;color:#fff;font-size:0.75em;line-height:2em}
div {padding:50px 0;text-align:center}
</style>
</head>
<body>

<div><img src="img/ajax-loader2.gif"><br>SMS를 전송 중입니다.<br>잠시만 기다려주십시오.</div>

</body>
</html>
